Bannermaker version 1.0.0  is a free software which is developed by
Kian William Nowrouzian. 
It is a package including both component, module and plugin.
Both component in site part and module use content plugin, so without it,
it will not work, also plugin shall be enabled automatically from Joomla backend,
yet check it after upload.
The license is GNU/GPLv3.
It is written for joomla 3.x,
In comment part for special characters add backslash(\) before them.
demo : http://www.extensions.lord121.ir/mycomponents/bannermaker-demo.html
download : http://www.extensions.lord121.ir/mycomponents/bannermaker-download.html
In case of any problem contact me at:
mezmer121@gmail.com
long live science.
